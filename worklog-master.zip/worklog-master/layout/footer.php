<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1
  </div>
  <strong>Copyright &copy; 2017 <a href="<?php echo site_url(); ?>">ระบบจัดการข้อมูล</a>.</strong> All rights reserved.
</footer>
</div>
<!-- ./wrapper -->
</body>

</html>
